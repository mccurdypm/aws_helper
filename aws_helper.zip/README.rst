AWS helper functions
=======================

from boto3
